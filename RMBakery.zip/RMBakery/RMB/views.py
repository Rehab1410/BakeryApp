from datetime import datetime
from flask import Blueprint, render_template, url_for, request, session, flash, redirect
from .models import Product, Category, Order
from datetime import datetime
from .forms import CheckoutForm
from . import db

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
   categories = Category.query.order_by(Category.name).all()
   return render_template('index.html', categories=categories)

@main_bp.route('/products/<int:categoryid>/')
def products(categoryid):
    products = Product.query.filter(Product.category_id==categoryid)
    return render_template('products.html', products = products)
   

# STUBS for routes not implemented yet
# (get_url links in the templates will fail without these routes defined)

@main_bp.route('/order', methods=['POST','GET'])
def order():
    product_id = request.values.get('product_id')

    # retrieve order if there is one
    if 'order_id' in session.keys():
        order = Order.query.get(session['order_id'])
        # order will be None if order_id stale
    else:
        # there is no order
        order = None
        
    # create new order if needed
    if order is None:
        order = Order(status = False, first_name='', surname='', email='', phone='', address='', total_cost=0, date=datetime.now())
        
    try:
            db.session.add(order)
            db.session.commit()
            session['order_id'] = order.id
    except:
            print('failed at creating a new order')
            order = None
    
    # calcultate totalprice
    total_price = 0 
    if order is not None:
         
         for product in order.products:
            total_price = total_price + product.price

    current_date = datetime.now()
    
    # are we adding an item?
    if product_id is not None and order is not None:
           product = Product.query.get(product_id)
           if product not in order.products:
            try:
                order.products.append(product)
                db.session.commit()
            except:
                return 'There was an issue adding the item to your Cart'
            return redirect(url_for('main.order'))
           else:
            flash('item already in cart')
            return redirect(url_for('main.order'))

    return render_template('order.html', order = order, total_price = total_price, current_date=current_date)




@main_bp.route('/deleteorderitem', methods=['POST'])
def deleteorderitem():
 id=request.form['id']
 if 'order_id' in session:
    order = Order.query.get_or_404(session['order_id'])
    product_to_delete = Product.query.get(id)
    try:
        order.products.remove(product_to_delete)
        db.session.commit()
        return redirect(url_for('main.order'))
    except:
        return 'Problem deleting item from order'
 return redirect(url_for('main.order'))   


# Scrap basket
@main_bp.route('/deleteorder')
def deleteorder():
     if 'order_id' in session:
      order_id = session['order_id']
      order = Order.query.get(order_id) 
      if order and order.products:
        for product in order.products:
            db.session.delete(product)
        flash('The cart is empty now!')   
      else:
        flash('There are no product in the cart to delete it!')
      del session['order_id']    
     else:
      flash('There are no product in the cart to delete it!')  
     return redirect(url_for('main.index'))

@main_bp.route('/checkout', methods=['POST','GET'])
def checkout():
    form = CheckoutForm() 

    if 'order_id' in session:

        order = Order.query.get_or_404(session['order_id'])
        total_cost=0
       
        for product in order.products:
            total_cost+=product.price

        if total_cost==0:
            flash('There are no products in the cart to purchase it!')
            return redirect(url_for('main.order')) 
        else:  
         if form.validate_on_submit():

            order.status = True

            order.first_name = form.first_name.data

            order.surname = form.surname.data

            order.email = form.email.data

            order.phone = form.phone.data

            order.address = form.address.data
 
            order.total_cost = total_cost

            order.date=datetime.now()

            try:

                db.session.commit()

                del session['order_id']

                flash('Thank you! your order will be with you soon')
                

                return redirect(url_for('main.index'))

            except:

                return 'There was an issue completing your order'

    return render_template('checkout.html', form=form)



@main_bp.route('/products')

def search():

 search = request.args.get('search')

 search = '%{}%'.format(search) # substrings will match

 products = Product.query.filter(Product.description.like(search)).all()

 return render_template('products.html', products=products)